package com.etraveli.movie.rental.service;
import com.etraveli.movie.rental.dto.Customer;

public interface RentalInfoService {

   String statement(Customer customer) ;
}
