package com.etraveli.movie.rental.service.impl;

import java.util.HashMap;

import com.etraveli.movie.rental.dto.Customer;
import com.etraveli.movie.rental.dto.Movie;
import com.etraveli.movie.rental.dto.MovieRental;
import com.etraveli.movie.rental.service.RentalInfoService;

public class RentalInfoServiceImpl implements RentalInfoService{
	
	
	 public String statement(Customer customer) {
		 
		    HashMap<String, Movie> movies = new HashMap();
		    movies.put("F001", new Movie("You've Got Mail", "regular"));
		    movies.put("F002", new Movie("Matrix", "regular"));
		    movies.put("F003", new Movie("Cars", "childrens"));
		    movies.put("F004", new Movie("Fast & Furious X", "new"));

		    double totalAmount = 0;
		    int frequentEnterPoints = 0;
		    
		    String result = "Rental Record for " + customer.getName() + "\n";
		   
		   
		    
		    
		    //  streams -->  for each we can use
		    for (MovieRental r : customer.getRentals()) {
		      double thisAmount = 0;

		      
		    //---> functional interface 
		      // determine amount for each movie
		      // interface calulateRental(){   }
		      
		       
		      if (movies.get(r.getMovieId()).getCode().equals("regular")) {
		       
		    	thisAmount = 2;
		        if (r.getDays() > 2) {
		          thisAmount = ((r.getDays() - 2) * 1.5) + thisAmount;
		        }
		      }
		      
		      //---> functional interface 
		      if (movies.get(r.getMovieId()).getCode().equals("new")) {
		        thisAmount = r.getDays() * 3;
		      }
		      
		      
		      if (movies.get(r.getMovieId()).getCode().equals("childrens")) {
		        thisAmount = 1.5;
		        if (r.getDays() > 3) {
		          thisAmount = ((r.getDays() - 3) * 1.5) + thisAmount;
		        }
		      }

		      //add frequent bonus points
		      frequentEnterPoints++;
		      // add bonus for a two day new release rental
		      if (movies.get(r.getMovieId()).getCode() == "new" && r.getDays() > 2) frequentEnterPoints++;

		      //print figures for this rental
		      result += "\t" + movies.get(r.getMovieId()).getTitle() + "\t" + thisAmount + "\n";
		      totalAmount = totalAmount + thisAmount;
		    }
		    
		    
		    // add footer lines
		    result += "Amount owed is " + totalAmount + "\n";
		    result += "You earned " + frequentEnterPoints + " frequent points\n";

		    return result;
		  }
	
	 //  will create seperate function/ method/service  which will calculate according to type
	 // regualar / chlidren / new /regular so repetation of code is avoided    
	 
	 // HashMap /--- can read from properties so that could be configured    
	 
	 
	void calculateMovieRent(HashMap<String, Movie> movies,MovieRental r,Integer thisAmount,String type ){
		thisAmount = 2;
        
	}
}
