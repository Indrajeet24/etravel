package com.etraveli.test.service;

import java.util.Arrays;

import com.etraveli.movie.rental.dto.Customer;
import com.etraveli.movie.rental.dto.MovieRental;
import com.etraveli.movie.rental.service.RentalInfoService;
import com.etraveli.movie.rental.service.impl.RentalInfoServiceImpl;

public class RentalInfoServiceTest {

	public static void Main(String[] args) {
		testCase1();
	}
	
	static void testCase1(){
	 
	RentalInfoService reInfo=new RentalInfoServiceImpl();
	
	 String result = reInfo.statement(new Customer("C. U. Stomer", Arrays.asList(new MovieRental("F001", 3), new MovieRental("F002", 1))));
	 
	 String expected = "Rental Record for C. U. Stomer\n\tYou've Got Mail\t3.5\n\tMatrix\t2.0\nAmount owed is 5.5\nYou earned 2 frequent points\n";
	
	 
	  if (!result.equals(expected)) {
	      throw new AssertionError("Expected: " + System.lineSeparator() + String.format(expected) + System.lineSeparator() + System.lineSeparator() + "Got: " + System.lineSeparator() + result);
	   }

	    System.out.println("Success  - Movie rented cost \n "+result );
	}
}
